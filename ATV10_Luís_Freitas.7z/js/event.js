/* Conteúdo do arquivo event.js */

function mouseOver() {
    document.imagem.src = 'img/cat02.png';
}

function mouseOut() {
    document.imagem.src = 'img/cat01.png';
}